
#' T cell inflamed Function 
#' 
#' It is important to distinguish the T cell inflamed Tumor types(Hot tumor) and non-T cell inflamed tumor types(Cold Tumor) for successful cancer immuno-therapy. 
#' This function distinguish the T cell inflamed, Non T cell inflamed, Intermediate phenotype in the cancer RNA sequencing data.
#' 
#' @param Inputfile You can simply use log CPM expression file(csv) which contains T cell relative Genes(row name) and it's expressions
#' @param Numberofgenes You can write number of testing genes (upper T cell relative genes). 
#' @keywords T cell inflamed Tumor, Non T cell inflamed Tumor, Intermediate 
#' @export
#' @examples TcellInflamedDetector(RNAexpression.csv,CTLfile)
#' @author  San-Duk Yang, Hyun-Seok Park



TcellInflamedDetector<-function(Inputfile,CTLfile){
  
  CTL_list<-CTLfile$Gene
  CTL<-as.vector(CTL_list)
  #CTL<-c("GZMA","PRF","GZMB","PRF1","EOMES","IFNG","TNF","CXCL9","CXCL10","CD8A","CD4","FOXP3","ICOS","CTLA4","IRF1","CCL2","CCL3","CCL4","GZMK","HLA.DMA","HLA.DMB","HLA.DOA","HLA.DOB","CCL5","CD27","CD274","PDCD1LG2","CD276","CMKLR1","CXCR6","HLA.DQA1","HLA.DRB1","HLA.E","IDO1","LAG3","NKG7","PSMB10","STAT1","TIGIT")
  Tcellgene<-Inputfile$Gene %in% CTL
  CTL_selected_inputfile<-Inputfile[Tcellgene,]
  write.csv(CTL_selected_inputfile,"CTL_Selected_Inputfile.csv")
  raw_data1<-as.matrix(CTL_selected_inputfile[,-1])
  zscore_data<-t(scale(t(raw_data1)))
  write.csv(zscore_data,"zscore_data.csv")
  x<-zscore_data
  x[x>0.1]<-1
  x[x<0.1]<--1
  write.csv(x,"zscore_convert.csv")
  colsum<-colSums(x)
  write.csv(colsum,"Zscore_convert_sum.csv")
  Numberofgenes<-nrow(CTL_selected_inputfile)
  Tcell_NonTcell<-ifelse(colsum>(Numberofgenes/2), "Tcell inflamed", ifelse(colsum< -(Numberofgenes/2),"Non Tcell inflamed","Intermediate" ))
  mat1<-as.matrix(Tcell_NonTcell)
  colnames(mat1)<-c("ID")
  write.table(mat1,"Tcell_NonTcell_Result.csv",sep = ",")
  
}
