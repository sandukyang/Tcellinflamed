
#' T cell inflamed Function 
#' 
#' This function distinguish T cell inflamed tumor types form non T cell inflamed tumor types. 
#' 
#' @param Inputfile You can simply use log CPM file(csv) which contains T cell relative Genes(row name) and it's expressions
#' @param Numberofgenes You can write number of testing genes (upper T cell relative genes). 
#' @keywords T cell inflamed Tumor, Non T cell inflamed Tumor 
#' @export
#' @examples Tcellinflamed_Function(a.csv,nrow(inputfilelist))
#' @examples Tcellinflamed_Function(b.csv,7)
#' @author  San-Duk Yang, Hyun-Seok Park




Tcellinflamed_Function<-function(Inputfile,Numberofgenes){
  raw_data1<-as.matrix(Inputfile[,-1])
  zscore_data<-t(scale(t(raw_data1)))
  write.csv(zscore_data,"zscore_data.csv")
  x<-zscore_data
  x[x>0.1]<-1
  x[x<0.1]<--1
  write.csv(x,"zscore_convert.csv")
  colsum<-colSums(x)
  write.csv(colsum,"Zscore_convert_sum.csv")
  Tcell_NonTcell<-ifelse(colsum>(Numberofgenes/2), "Tcell inflamed", ifelse(colsum< -(Numberofgenes/2),"Non Tcell inflamed","Intermediate" ))
  
  mat1<-as.matrix(Tcell_NonTcell)
  colnames(mat1)<-c("ID")
  write.table(mat1,"Tcell_NonTcell_Result.csv",sep = ",")
}
